<?php
    $now = new \Carbon\Carbon();
?>

<table>
    <thead>
        <tr>
            <th></th>
            <th>REPORTE BUQUES</th>
        </tr>
        <tr>
            <td>Fecha</td>
            <th><?php echo e($now->format('d/m/Y h:m A')); ?></th>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <th>
                Fecha
            </th>
            <th>
                Documento
            </th>
            <th>
                Vessel
            </th>
            <th>
                Hora Atraque
            </th>
            <th>
                Hora preparacion
            </th>
            <th>
                Hora inicio maniobra
            </th>
            <th>
                Final de maniobra
            </th>
            <th>
                Total de maniobras
            </th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $buques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($buque->Fechab); ?>

                </td>
                <td>
                    <?php echo e($buque->Nodoc); ?>

                </td>
                <td>
                    <?php echo e($buque->Barco); ?>

                </td>
                <td>
                    <?php echo e($buque->Hatraque); ?>

                </td>
                <td>
                    <?php echo e($buque->Havisopre); ?>

                </td>
                <td>
                    <?php echo e($buque->Iniman); ?>

                </td>
                <td>
                    <?php echo e($buque->Fultman); ?>

                </td>
                <td>
                    <?php echo e($buque->Titotmanio); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /Users/luisvasquez/Sites/shawcor/resources/views/exports/buques/export.blade.php ENDPATH**/ ?>