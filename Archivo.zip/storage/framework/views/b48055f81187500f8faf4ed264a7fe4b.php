<?php
    $now = new \Carbon\Carbon();
?>

<table>
    <thead>
        <tr>
            <th></th>
            <th>Reporte Gruas</th>
        </tr>
        <tr>
            <td>Fecha</td>
            <th><?php echo e($now->format('d/m/Y')); ?></th>
        </tr>
        <tr>
            <th>DATE</th>
            <th>VESSEL</th>
            <th>TOTAL TIME</th>
            <th>CODE</th>
            <th>OBSERVATIONS</th>
            <th>TIME</th>
            <th>MANIOBRAS</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $gruas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($grua->date); ?>

                </td>
                <td>
                    <?php echo e($grua->vessel); ?>

                </td>
                <td>
                    <?php echo e($grua->totaltime); ?>

                </td>
                <td>
                    <?php echo e($grua->code); ?>

                </td>
                <td>
                    <?php echo e($grua->observations); ?>

                </td>
                <td>
                    <?php echo e($grua->time); ?>

                </td>
                <td>
                    <?php echo e($grua->maniobras); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /Users/luisvasquez/Sites/shawcor/resources/views/exports/gruas/export.blade.php ENDPATH**/ ?>