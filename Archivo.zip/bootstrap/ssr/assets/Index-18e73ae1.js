import { unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-4694a0c6.js";
import { Head } from "@inertiajs/vue3";
import "./ApplicationLogo-0d2bcac8.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    buques: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Profile" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight"${_scopeId}>Temp Buques</h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight" }, "Temp Buques")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6"${_scopeId}><div class="overflow-x-auto shadow-md sm:rounded-lg flex justify-end items-center"${_scopeId}><a${ssrRenderAttr("href", _ctx.route("buques.export"))} target="_blank" class="text-white bg-gradient-to-r from-green-400 via-green-500 to-green-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-green-300 dark:focus:ring-green-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2"${_scopeId}>Descarga Excel</a></div><div class="relative overflow-x-auto shadow-md sm:rounded-lg"${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="px-6 py-3"${_scopeId}> # </th><th scope="col" class="px-6 py-3"${_scopeId}> Fecha </th><th scope="col" class="px-6 py-3"${_scopeId}> Documento </th><th scope="col" class="px-6 py-3"${_scopeId}> Vessel </th><th scope="col" class="px-6 py-3"${_scopeId}> Hora Atraque </th><th scope="col" class="px-6 py-3"${_scopeId}> Hora preparacion </th><th scope="col" class="px-6 py-3"${_scopeId}> Hora inicio maniobra </th><th scope="col" class="px-6 py-3"${_scopeId}> Final de maniobra </th><th scope="col" class="px-6 py-3"${_scopeId}> Total de maniobras </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.buques.data, (buque) => {
              _push2(`<tr class="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700"${_scopeId}><th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"${_scopeId}>${ssrInterpolate(buque.id)}</th><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(buque.Fechab)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(buque.Nodoc)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(buque.Barco)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(buque.Hatraque)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(buque.Havisopre)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(buque.Iniman)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(buque.Fultman)}</td><td class="px-6 py-4"${_scopeId}>${ssrInterpolate(buque.Titotmanio)}</td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div><nav aria-label="Page navigation example"${_scopeId}><ul class="inline-flex -space-x-px text-sm"${_scopeId}><!--[-->`);
            ssrRenderList(__props.buques.links, (buque, index) => {
              _push2(`<li${_scopeId}>`);
              if (index == 0) {
                _push2(`<a${ssrRenderAttr("href", buque.url)} class="flex items-center justify-center px-3 h-8 ms-0 leading-tight text-gray-500 bg-white border border-e-0 border-gray-300 rounded-s-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"${_scopeId}>${buque.label}</a>`);
              } else {
                _push2(`<!---->`);
              }
              if (index != 0 && index != __props.buques.links.length - 1) {
                _push2(`<a${ssrRenderAttr("href", buque.url)} class="${ssrRenderClass([{ "text-blue-600 bg-blue-50 hover:bg-blue-100 hover:text-blue-700": buque.active }, "flex items-center justify-center px-3 h-8 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"])}"${_scopeId}>${ssrInterpolate(buque.label)}</a>`);
              } else {
                _push2(`<!---->`);
              }
              if (index == __props.buques.links.length - 1) {
                _push2(`<a${ssrRenderAttr("href", buque.url)} class="flex items-center justify-center px-3 h-8 leading-tight text-gray-500 bg-white border border-gray-300 rounded-e-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"${_scopeId}>${buque.label}</a>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</li>`);
            });
            _push2(`<!--]--></ul></nav></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6" }, [
                  createVNode("div", { class: "overflow-x-auto shadow-md sm:rounded-lg flex justify-end items-center" }, [
                    createVNode("a", {
                      href: _ctx.route("buques.export"),
                      target: "_blank",
                      class: "text-white bg-gradient-to-r from-green-400 via-green-500 to-green-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-green-300 dark:focus:ring-green-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2"
                    }, "Descarga Excel", 8, ["href"])
                  ]),
                  createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg" }, [
                    createVNode("table", { class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" }, [
                      createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                        createVNode("tr", null, [
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " # "),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " Fecha "),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " Documento "),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " Vessel "),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " Hora Atraque "),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " Hora preparacion "),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " Hora inicio maniobra "),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " Final de maniobra "),
                          createVNode("th", {
                            scope: "col",
                            class: "px-6 py-3"
                          }, " Total de maniobras ")
                        ])
                      ]),
                      createVNode("tbody", null, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.buques.data, (buque) => {
                          return openBlock(), createBlock("tr", {
                            class: "odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700",
                            key: `buque-${buque.id}`
                          }, [
                            createVNode("th", {
                              scope: "row",
                              class: "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                            }, toDisplayString(buque.id), 1),
                            createVNode("td", { class: "px-6 py-4" }, toDisplayString(buque.Fechab), 1),
                            createVNode("td", { class: "px-6 py-4" }, toDisplayString(buque.Nodoc), 1),
                            createVNode("td", { class: "px-6 py-4" }, toDisplayString(buque.Barco), 1),
                            createVNode("td", { class: "px-6 py-4" }, toDisplayString(buque.Hatraque), 1),
                            createVNode("td", { class: "px-6 py-4" }, toDisplayString(buque.Havisopre), 1),
                            createVNode("td", { class: "px-6 py-4" }, toDisplayString(buque.Iniman), 1),
                            createVNode("td", { class: "px-6 py-4" }, toDisplayString(buque.Fultman), 1),
                            createVNode("td", { class: "px-6 py-4" }, toDisplayString(buque.Titotmanio), 1)
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  createVNode("nav", { "aria-label": "Page navigation example" }, [
                    createVNode("ul", { class: "inline-flex -space-x-px text-sm" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(__props.buques.links, (buque, index) => {
                        return openBlock(), createBlock("li", {
                          key: `item-${buque.label}`
                        }, [
                          index == 0 ? (openBlock(), createBlock("a", {
                            key: 0,
                            href: buque.url,
                            class: "flex items-center justify-center px-3 h-8 ms-0 leading-tight text-gray-500 bg-white border border-e-0 border-gray-300 rounded-s-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white",
                            innerHTML: buque.label
                          }, null, 8, ["href", "innerHTML"])) : createCommentVNode("", true),
                          index != 0 && index != __props.buques.links.length - 1 ? (openBlock(), createBlock("a", {
                            key: 1,
                            href: buque.url,
                            class: ["flex items-center justify-center px-3 h-8 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white", { "text-blue-600 bg-blue-50 hover:bg-blue-100 hover:text-blue-700": buque.active }]
                          }, toDisplayString(buque.label), 11, ["href"])) : createCommentVNode("", true),
                          index == __props.buques.links.length - 1 ? (openBlock(), createBlock("a", {
                            key: 2,
                            href: buque.url,
                            class: "flex items-center justify-center px-3 h-8 leading-tight text-gray-500 bg-white border border-gray-300 rounded-e-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white",
                            innerHTML: buque.label
                          }, null, 8, ["href", "innerHTML"])) : createCommentVNode("", true)
                        ]);
                      }), 128))
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Buques/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
