import { unref, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-4694a0c6.js";
import { Head } from "@inertiajs/vue3";
import "./ApplicationLogo-0d2bcac8.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight"${_scopeId}>Dashboard</h2>`);
          } else {
            return [
              createVNode("h2", { class: "font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight" }, "Dashboard")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-12"${_scopeId}><div class="max-w-7xl mx-auto sm:px-6 lg:px-8"${_scopeId}><div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg flex flex-nowrap justify-around p-7"${_scopeId}><div class="w-1/3 d-flex"${_scopeId}><a${ssrRenderAttr("href", _ctx.route("buques.index"))}${_scopeId}><img src="/images/vessel_times.jpeg" alt="Vessel times" class="w-full"${_scopeId}></a></div><div class="w-1/3 d-flex"${_scopeId}><a${ssrRenderAttr("href", _ctx.route("gruas.index"))}${_scopeId}><img src="/images/crane_downtime.jpeg" alt="Crane downtime" class="w-full"${_scopeId}></a></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-12" }, [
                createVNode("div", { class: "max-w-7xl mx-auto sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg flex flex-nowrap justify-around p-7" }, [
                    createVNode("div", { class: "w-1/3 d-flex" }, [
                      createVNode("a", {
                        href: _ctx.route("buques.index")
                      }, [
                        createVNode("img", {
                          src: "/images/vessel_times.jpeg",
                          alt: "Vessel times",
                          class: "w-full"
                        })
                      ], 8, ["href"])
                    ]),
                    createVNode("div", { class: "w-1/3 d-flex" }, [
                      createVNode("a", {
                        href: _ctx.route("gruas.index")
                      }, [
                        createVNode("img", {
                          src: "/images/crane_downtime.jpeg",
                          alt: "Crane downtime",
                          class: "w-full"
                        })
                      ], 8, ["href"])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
