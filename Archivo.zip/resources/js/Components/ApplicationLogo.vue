<template>
    <img src="/images/logo.png" alt="">
</template>
